import os
import pandas as pd


names = ['aditya', 'adnan','ajay','akshay','akshit','animesh','ann','apoorva','arjun','athira','atif', 'atmadeep', 
        'balveer','bhaswati', 'bimal','bubai',
        'deepak','devika','diganta',
        'florence','hardik',
        'ishani',
        'kartik','kaustav',
        'madhumanti','maithili','malaya','maneesh','mithun','muthamil',
        'nandini','nikhil', "na3", "nh18",
        'prachi','prasanjit','pratim','pritam','priya',
        'rahul','rahulk','rahulr','rakesh','ranajit','rindhya','rohan','ronick',
        'sanjoli','sayantan','papai','sayli','sazia','shailesh','shivangi','shloka','shubham','sonali','soumitra', "soumyadeep",'srishti','sudarsun','suman','sumit','sushmita', 'swati',
        'trideet',
        'utanko','utkarsh',
        'vaibhav','vaishnavi','vinay',
        'yadnesh',
        'zainab']

name_alt = dict()
for idx, name in enumerate(names):
    name_alt[name] = "tnh_"+str(idx)

save_to_path = "C:\\Users\\atifh\\Desktop\\data\\DnB2\\chunks25\\train_new\\"
directory_path = "C:\\Users\\atifh\\Desktop\\data\\DnB2\\chunks25\\train\\"

for entry in os.listdir(directory_path):
    full_path = os.path.join(directory_path, entry)
    if ".xlsx" in full_path:
        df = pd.read_excel(full_path)
        filename = name_alt[entry[:entry.find(".")]]
        df.to_excel(save_to_path+filename+".xlsx", index=False)
        